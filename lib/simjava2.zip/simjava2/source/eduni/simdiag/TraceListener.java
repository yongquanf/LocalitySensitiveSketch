package eduni.simdiag;
 
import java.util.EventListener;

/**
 * Timing diagram event listener interface 
 */
 

public interface TraceListener extends EventListener {
  /** Processes the given trace event object.
   */
  void handleTrace(TraceEventObject teo);
}
